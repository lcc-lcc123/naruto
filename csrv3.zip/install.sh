#!/bin/bash
# 火影忍者联机 · 云服务端一键部署 (Ubuntu/Debian)
# 用法: 把本包所有文件上传到服务器同一目录, 然后运行: bash install.sh
set -e
echo "== 1/4 安装 Node.js =="
if ! command -v node >/dev/null 2>&1; then
  sudo apt-get update -y
  sudo apt-get install -y nodejs npm
fi
node -v

echo "== 2/4 放行端口 3777(本机防火墙) =="
if command -v ufw >/dev/null 2>&1; then
  sudo ufw allow 3777/tcp || true
fi
if command -v firewall-cmd >/dev/null 2>&1; then
  sudo firewall-cmd --permanent --add-port=3777/tcp || true
  sudo firewall-cmd --reload || true
fi

echo "== 3/4 注册开机自启服务 =="
DIR=$(cd "$(dirname "$0")" && pwd)
sudo tee /etc/systemd/system/naruto-srv.service >/dev/null <<EOF
[Unit]
Description=Naruto Cloud Server
After=network.target
[Service]
WorkingDirectory=$DIR
ExecStart=$(command -v node) $DIR/server.js --port=3777 --datadir=$DIR/data
Restart=always
[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable naruto-srv
sudo systemctl restart naruto-srv

echo "== 4/4 完成 =="
IP=$(curl -s --max-time 8 ifconfig.me || echo "你的服务器公网IP")
echo ""
echo "=============================================="
echo "  部署完成!"
echo "  手机游戏网址: http://$IP:3777/game"
echo "  游戏内服务器地址填: http://$IP:3777"
echo "=============================================="
echo "  重要: 还需要在云服务器控制台的【安全组/防火墙】"
echo "  里放行 TCP 3777 端口, 否则手机连不上!"
