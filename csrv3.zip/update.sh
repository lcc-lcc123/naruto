#!/bin/bash
# 极简云服务端更新脚本
# 用法: bash update.sh https://lcc-lcc123.github.io/naruto/csrv.zip
URL=$1
if [ -z "$URL" ]; then
  echo "用法: bash update.sh <安装包下载地址>"
  exit 1
fi
cd "$(dirname "$0")"
echo "== 下载更新包 =="
curl -L --max-time 120 -o /tmp/pkg.zip "$URL" || { echo "下载失败"; exit 1; }
apt-get install -y -qq unzip >/dev/null 2>&1
unzip -o /tmp/pkg.zip -d /tmp/pkg_new >/dev/null
echo "== 覆盖文件 =="
cp -f /tmp/pkg_new/*.js . 2>/dev/null
cp -f /tmp/pkg_new/*.html . 2>/dev/null
cp -f /tmp/pkg_new/*.sh . 2>/dev/null
rm -rf /tmp/pkg_new /tmp/pkg.zip
echo "== 重启服务 =="
systemctl restart naruto-srv
sleep 1
systemctl status naruto-srv --no-pager | head -5
IP=$(curl -s --max-time 8 ifconfig.me || echo "服务器公网IP")
echo ""
echo "更新完成! 首页: http://$IP/"
