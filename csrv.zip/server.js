// 火影忍者联机 · 云信令服务端 (Node.js 零依赖, 兼容极简聊天 v3.0.5 游戏协议)
// 用法: node server.js --port=3777 --datadir=./data
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const m = process.argv[i].match(/^--([^=]+)=(.*)$/);
  if (m) args[m[1]] = m[2];
}
const PORT = parseInt(args.port || '3777', 10);
const DATADIR = args.datadir || path.join(__dirname, 'data');
const GAMEHTML = args.game || path.join(__dirname, 'naruto.html');
try { fs.mkdirSync(DATADIR, { recursive: true }); } catch (e) {}

// ---------- 状态 ----------
const state = { users: {}, friends: {}, messages: [], nextId: 1 };
const stateFile = path.join(DATADIR, 'state.json');
function loadState() {
  try {
    const s = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    state.users = s.users || {};
    state.friends = s.friends || {};
    state.messages = s.messages || [];
    state.nextId = s.nextId || 1;
  } catch (e) {}
}
function saveState() {
  try { fs.writeFileSync(stateFile, JSON.stringify(state)); } catch (e) {}
}
loadState();
const sessions = {};   // token -> name
const lastSeen = {};   // name -> ts

function now() { return Date.now(); }
function sha(s) { return crypto.createHash('sha256').update(s, 'utf8').digest('hex'); }
function colorOf(n) {
  let h = 7;
  for (let i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) >>> 0;
  return '#' + ('00000' + (h & 0x7fffff).toString(16)).slice(-6);
}
function purgeSessions() {
  const t = now();
  for (const k in sessions) {
    if (t - (lastSeen[sessions[k]] || 0) > 20000) delete sessions[k];
  }
}
function onlineOf(name) {
  for (const k in sessions) if (sessions[k] === name) return true;
  return false;
}
function newToken(name) {
  const t = crypto.randomBytes(16).toString('hex');
  sessions[t] = name;
  lastSeen[name] = now();
  return t;
}
function isFriend(a, b) {
  const f = state.friends[a];
  return !!(f && f.indexOf(b) >= 0);
}
function addFriendPair(a, b) {
  if (!state.friends[a]) state.friends[a] = [];
  if (!state.friends[b]) state.friends[b] = [];
  if (state.friends[a].indexOf(b) < 0) state.friends[a].push(b);
  if (state.friends[b].indexOf(a) < 0) state.friends[b].push(a);
}

// ---------- HTTP ----------
function send(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-cache',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  });
  res.end(b);
}
function ok(res, obj) { send(res, 200, obj); }
function fail(res, code, msg) { send(res, code, { ok: false, error: msg }); }
function readBody(req) {
  return new Promise(function (resolve) {
    const chunks = [];
    let size = 0;
    req.on('data', function (c) {
      size += c.length;
      if (size > 1024 * 1024) { req.destroy(); resolve(''); return; }
      chunks.push(c);
    });
    req.on('end', function () { resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', function () { resolve(''); });
  });
}
function qp(req, key) {
  try { return new URL(req.url, 'http://x').searchParams.get(key); } catch (e) { return null; }
}
function auth(req) {
  const t = qp(req, 'token');
  if (!t) return null;
  purgeSessions();
  return sessions[t] || null;
}
function serveFile(res, file, type) {
  try {
    const b = fs.readFileSync(file);
    res.writeHead(200, {
      'Content-Type': type,
      'Cache-Control': 'no-cache',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(b);
  } catch (e) {
    fail(res, 404, '文件不存在: ' + file);
  }
}

const server = http.createServer(async function (req, res) {
  let p = '/';
  try { p = new URL(req.url, 'http://x').pathname; } catch (e) {}

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    });
    res.end();
    return;
  }

  if (p === '/game' || p === '/game/') { serveFile(res, GAMEHTML, 'text/html; charset=utf-8'); return; }
  if (p === '/') { res.writeHead(302, { 'Location': '/game' }); res.end(); return; }

  if (p === '/api/status') { ok(res, { ok: true, app: '极简聊天云服务端', version: '3.1.0' }); return; }

  if (p === '/api/register') {
    const b = JSON.parse((await readBody(req)) || '{}');
    const n = String(b.name || '').trim().slice(0, 20);
    const pw = String(b.password || '');
    if (!n) return fail(res, 400, '昵称需为1-20位字符');
    if (pw.length < 4 || pw.length > 32) return fail(res, 400, '密码需为4-32位');
    if (state.users[n]) return fail(res, 409, '该昵称已被注册，请直接登录');
    const salt = crypto.randomBytes(16).toString('hex');
    state.users[n] = { name: n, color: colorOf(n), salt: salt, hash: sha(salt + pw) };
    saveState();
    return ok(res, { ok: true, user: { name: n, color: state.users[n].color }, token: newToken(n) });
  }

  if (p === '/api/login') {
    const b = JSON.parse((await readBody(req)) || '{}');
    const n = String(b.name || '').trim().slice(0, 20);
    const pw = String(b.password || '');
    const u = state.users[n];
    if (!u) return fail(res, 404, '用户不存在，请先注册');
    if (sha(u.salt + pw) !== u.hash) return fail(res, 401, '密码错误');
    return ok(res, { ok: true, user: { name: n, color: u.color }, token: newToken(n) });
  }

  if (p === '/api/ping') {
    const name = auth(req);
    if (name) lastSeen[name] = now();
    return ok(res, { ok: true });
  }

  if (p === '/api/friends' && req.method === 'GET') {
    const name = auth(req);
    if (!name) return fail(res, 401, '请先登录');
    const list = (state.friends[name] || []).filter(function (x) { return state.users[x]; }).map(function (x) {
      return { name: x, color: state.users[x].color, online: onlineOf(x) };
    });
    return ok(res, { ok: true, friends: list, requests: [] });
  }

  if (p === '/api/friends/add') {
    const name = auth(req);
    if (!name) return fail(res, 401, '请先登录');
    const b = JSON.parse((await readBody(req)) || '{}');
    const target = String(b.name || '').trim().slice(0, 20);
    if (!target || target === name) return fail(res, 400, '昵称无效');
    if (!state.users[target]) return fail(res, 404, '用户不存在');
    if (isFriend(name, target)) return fail(res, 409, '你们已经是好友了');
    addFriendPair(name, target);   // 云版: 直接成为好友(游戏内无审批界面)
    saveState();
    return ok(res, { ok: true });
  }

  if (p === '/api/friends/accept' || p === '/api/friends/reject' || p === '/api/friends/remove') {
    if (!auth(req)) return fail(res, 401, '请先登录');
    return ok(res, { ok: true });  // 兼容占位
  }

  if (p === '/api/messages' && req.method === 'GET') {
    const name = auth(req);
    if (!name) return fail(res, 401, '请先登录');
    const after = parseInt(qp(req, 'after') || '0', 10) || 0;
    const vis = state.messages.filter(function (m) { return m.to === name || m.from === name; });
    let list;
    if (after > 0) list = vis.filter(function (m) { return m.id > after; });
    else list = vis.slice(-200);
    return ok(res, { ok: true, messages: list, latestId: state.nextId - 1, updates: [] });
  }

  if (p === '/api/messages' && req.method === 'POST') {
    const name = auth(req);
    if (!name) return fail(res, 401, '请先登录');
    const b = JSON.parse((await readBody(req)) || '{}');
    let text = String(b.text || '').trim();
    const to = String(b.to || '').trim().slice(0, 64);
    if (!text) return fail(res, 400, '消息不能为空');
    if (text.length > 2000) text = text.slice(0, 2000);
    if (!to || to === name) return fail(res, 400, '收件人无效');
    if (!state.users[to]) return fail(res, 404, '用户不存在');
    if (!isFriend(name, to)) return fail(res, 403, '你们还不是好友，请先添加好友');
    const m = { id: state.nextId++, from: name, to: to, type: 'text', text: text, time: now() };
    state.messages.push(m);
    if (state.messages.length > 5000) state.messages.splice(0, state.messages.length - 5000);
    saveState();
    return ok(res, { ok: true, message: m });
  }

  fail(res, 404, '未知接口: ' + p);
});

server.listen(PORT, '0.0.0.0', function () {
  console.log('NarutoCloud server listening on 0.0.0.0:' + PORT + ' datadir=' + DATADIR);
});
